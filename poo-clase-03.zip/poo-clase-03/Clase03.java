import java.util.Scanner;

public class Clase03 {
    public static void main(String[] args) {
        // Estructuras

        // Condicionales

        // IF
        int numero1 = 10;
        int numero2 = 20;

        if (numero1 > numero2) {
            System.out.println("El número 1 es mayor que el número 2");
        }

        if (numero1 > numero2) System.out.println("El número 1 es mayor que el número 2");
        //if en línea, se escribe todo en una línea si en el cuerpo del if hay una sola instrucción


        // IF-ELSE
        if (numero1 > numero2) {
            System.out.println("El número 1 es mayor que el número 2");
        } else {
            System.out.println("El número 1 no es mayor que el número 2");
        }

        if (numero1 > numero2) System.out.println("El número 1 es mayor que el número 2");
        else System.out.println("El número 1 no es mayor que el número 2");
        // if-else en línea, se puede hacer si solo hay una única instrucción por bloque


        // IF ELSE EN CASCADA (IF-ELSE IF-ELSE)
        if (numero1 > numero2) {
            System.out.println("El número 1 es mayor que el número 2");
        } else if (numero1 < numero2){
            System.out.println("EL número 1 es menor que el número 2");
        } else {
            System.out.println("El número 1 y el número 2 son iguales.");
        }


        // IF-ELSE ANIDADO
        int edad = 22;
        boolean tienePasaporte = true;

        if (tienePasaporte) {
            if (edad >= 18) {
                System.out.println("Puede viajar solo.");
            } else {
                System.out.println("Puede viajar pero acompañado.");
            }
        } else {
            System.out.println("No puede viajar.");
        }

        
        // Operador ternario (if-else abreviado)
        // condicion ? valorVerdadero : valorFalso

        String mensaje = (edad >= 18) ? "Es mayor de edad" : "No es mayor de edad";
        System.out.println(mensaje);


        // SWITCH CASE
        int dia = 5;

        switch (dia) {
            case 1: System.out.println("Lunes"); break;
            case 2: System.out.println("Martes"); break;
            case 3: System.out.println("Miércoles"); break;
            case 4: System.out.println("Jueves"); break;
            case 5: System.out.println("Viernes"); break;
            case 6: System.out.println("Sábado"); break;
            case 7: System.out.println("Domingo"); break;
            default: System.out.println("El día no es válido.");
        }

        switch (dia) {
            case 1, 2, 3, 4, 5: System.out.println("Es día de semana"); break;
            case 6, 7: System.out.println("Es fin de semana"); break;
            default: System.out.println("No es un día válido");
        }

        // Rule switch (JDK 14)
        // se reemplazan los : por las -> 
        // desaparecen los break
        // además se puede utilizar para determinar una expresión

        String diaSemana = switch(dia){
                            case 1 -> "Lunes";
                            case 2 -> "Martes";
                            case 3 -> "Miércoles";
                            case 4 -> "Jueves";
                            case 5 -> "Viernes";
                            case 6 -> "Sábado";
                            case 7 -> "Domingo";
                            default -> "Día no válido";
        };
        // en el rule switch como expresión, es obligatorio el uso del default para asignar un valor.
        


        // Estructuras repetitivas

        // while
        int contador = 1;
        while (contador >= 10) {
            System.out.println(contador);
            contador ++;
        }

        // do-while con break y continue
        int numero = 0;
        int suma = 0;

        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese su nombre:");
        String nombre = sc.nextLine();
        System.out.println("Hola " + nombre);





    } // cierre del método main
} // cierre de la clase
