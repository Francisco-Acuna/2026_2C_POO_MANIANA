public class Clase02 {
    public static void main(String[] args) {
        /*
        Instituto: Centro de Formación Profesional N°8 - SMATA
        Curso: Programación Orientada a Objetos
        Lenguaje principal: Java
        Cursada: lunes, miércoles y viernes de 10 a 13.30hs.
        Profesor: Francisco Acuña
        Email: franciscoacuna.centro8@gmail.com
        Redes: F/IG franacuna.tech
        Repositorio: https://github.com/Francisco-Acuna/2026_2C_POO_MANIANA
        Softwares necesarios:
            - JDK (sugerido 25 LTS) → https://www.oracle.com/java/technologies/downloads/#java25
            - Visual Studio Code → https://code.visualstudio.com 
            - Extensión de VSC → Extension Pack for Java (by Microsoft)
            - MySQL y Workbench → https://dev.mysql.com/downloads/installer
        */

        // comentarios en línea

        /*
        comentarios
        en 
        bloque.
        Varias líneas.
        */

        /**
         * Comentarios del tipo
         * JavaDoc
         * Son en bloque y documentan el código.
         */

        
        //Etiquetas en comentarios
        //Instalar Better Todo Tree by Fanatic Pythoner

        //TODO: indican tareas pendientes por implementar o finalizar

        //FIXME: señalan errores o problemas que deben ser corregidos


        //Impresión por consola
        System.out.println("Hola Mundo!");
        //atajo de teclado sout + tab
        
        //Atajo de teclado para indentar el código automáticamente
        // alt + shift + f

        //Para ejecutar el código utilizamos Run o su atajo de teclado.     

        /*        
        camelCase → variables, atributos y métodos
        PascalCase → clases e interfaces
        snake_case → se suele utilizar en bases de datos
        kebab-case → suele utilizarse para nombrar carpetas
        */

        // declaración de variable
        int variable; //declaración de variable con tipo de dato e identificador
        variable = 10; //asignación de valor a la variable
        int variable2 = 20; //declaración y asignación de valor en línea
        int variable3=30, variable4=40, variable5=50; //declaración y asignación múltiple en línea

        variable = 20;
        // variable = "20"; ERROR - no se puede cambiar el tipo de dato
        // float variable; ERROR - la variable ya está declarada como entera

        /*
            Java es un lenguaje fuertemente tipado, por lo cual se deben respetar ciertos puntos.
            No se puede asignar otro tipo de dato como valor a una variable ya declarada.
            No puedo cambiar el tipo de dato de una variable ya declarada.
            No puedo crear otra variable con el mismo nombre.
            Una variable debe tener una única declaración.
            Una variable puede tener innumerables valores, siempre que sean del mismo tipo de dato.
        */

        // ** Tipos de datos primitivos **

        // byte - ocupa 1 byte y representa un número entero entre -128 y 127
        byte variableByte = 13;
        // byte variableByte2 = 130; ERROR - excede el límite de lo que puede guardar un tipo byte
        System.out.println(variableByte);

        // short - ocupa 2 bytes y representa un número entero entre -32.768 y 32.767
        short variableShort = 10000;
        System.out.println(variableShort);

        // int - ocupa 4 bytes y representa un número entero entre -2.147.483.648 y 2.147.483.647
        int variableInt = 2035157;
        System.out.println(variableInt);

        // long - ocupa 8 bytes y representa un número entero muy grande que va desde -2 elevado a la 63
        // hasta el 2 elevado a la 63 -1
        long variableLong = 87413511164132L;
        System.out.println(variableLong);
        //las variables tipo long deben llevar una L al final de su literal
        //utilizamos L mayúscula por convención ya que la l minúscula parace un 1

        // float - ocupa 4 bytes y tiene alrededor de 6-7 dígitos de precisión total
        float variableFloat = 2343.12f;
        //las variables del tipo float deben llevar una f al final de su literal
        //los decimales se separan con punto
        System.out.println(variableFloat);

        // double - ocupa 8 bytes y tiene alrededor de 15-16 dígitos de precisión total
        double variableDouble = 3244.12;
        //no llevan ninguna letra al final de la literal
        System.out.println(variableDouble);

        // boolean - almacena solo 2 valores posibles (true y false)
        boolean variableBoolean = true;
        System.out.println(variableBoolean);

        // char - ocupa 2 bytes y almacena un número entero que representa un caracter de la tabla UNICODE
        // UNICODE es un estándar de codificación de caracteres a nivel mundial
        char variableChar = 65;
        System.out.println(variableChar);
        variableChar = 'B'; // también se puede almacenar el caracter directamente
        //debe ir entre comillas simples

        // ** String **
        // no es un tipo de dato primitivo. Es una clase.
        // Representa una cadena de caracteres.
        String variableString = "Hola, loco.";
        System.out.println(variableString);

        // Existe en Java un tipo de datos especial → var
        // aparecen a partir del JDK 10.
        // No son un tipo de dato en sí mismo. Es una palabra clave que indica al compilador que infiera el tipo
        // de dato real a partr de la primera asignación de valor.


        // Concatenación de cadenas

        // operador de concatenación +
        String nombre = "Francisco";
        System.out.println("Hola " + nombre);

        // método String.format()
        // Permite formatear cadenas
        int edad = 24;
        String mensaje = String.format("Hola, mi nombre es %s y tengo %d años.", nombre, edad);
        System.out.println(mensaje);
        /*
        Usa los siguientes marcadores de posición:
        %s → cadenas de texto
        %d → números enteros
        %f → números decimales
        %n → salto de línea
        */

        // método System.out.printf()
        // Se utiliza para imprimir directamente con formato.
        System.out.printf("Hola, mi nombre es %s y tengo %d años.", nombre, edad);

        System.out.println();

        // ** Operadores **

        // Operadores aritméticos
        /*
        + suma
        - resta
        * multiplicación
        / división
        % módulo o resto de la división
        Son operadores binarios porque necesitan 2 operandos.
        Los operandos son numéricos y el resultado es numérico.
        */

        // Operadores de asignación
        /*
        =  asignación
        += suma y asignación
        -= resta y asignación
        *= multiplicación y asignación
        /= división y asignación
        %= módulo y asignación
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando una expresión.
        */

        // Operadores incrementales y decrementales
        /*
        ++ incremento en 1
        -- decremento en 1
        Puede utilizarse de dos formas:
        Prefijo (++x o --x): la variable se modifica antes de que se use su valor en la expresión
        Postfijo (x++ o x--): la variable se modifica después de que se use su valor en una expresión.
        Son operadores unarios, trabajan con un solo operador.
        */

        // Operadores relacionales
        /*
        >  mayor 
        <  menor
        >= mayor o igual
        <= menor o igual
        == igual
        != distinto
        Son operadores binarios.
        Los operandos son numéricos y el resultado es binario.
        */

        // Operadores lógicos
        /*
        &  AND (es un y lógico)
        |  OR (es un o lógico)
        !  NOT (negación)
        Los operandos son booleanos.
        El resultado es booleano. 
        */

        /*
        Un solo operador lógico & o | evalúa ambas condiciones.
        Al utilizar dos && o || si con una condición determina el valor de verdad, no evalúa la condición que sigue.
        */

    }
}
