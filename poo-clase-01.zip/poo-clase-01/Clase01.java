public class Clase01 {
    public static void main(String[] args) {
        /*
        Instituto: Centro de Formación Profesional N°8 - SMATA
        Curso: Programación Orientada a Objetos
        Lenguaje principal: Java
        Cursada: lunes, miércoles y viernes de 10 a 13.30hs.
        Profesor: Francisco Acuña
        Email: franciscoacuna.centro8@gmail.com
        Redes: F/IG franacuna.tech
        Repositorio: https://github.com/Francisco-Acuna/2026_2C_POO_MANIANA
        Softwares necesarios:
            - JDK (sugerido 25 LTS) → https://www.oracle.com/java/technologies/downloads/#java25
            - Visual Studio Code → https://code.visualstudio.com 
            - Extensión de VSC → Extension Pack for Java (by Microsoft)
            - MySQL y Workbench → https://dev.mysql.com/downloads/installer
        */

        // comentarios en línea

        /*
        comentarios
        en 
        bloque.
        Varias líneas.
        */

        /**
         * Comentarios del tipo
         * JavaDoc
         * Son en bloque y documentan el código.
         */

        
        //Etiquetas en comentarios
        //Instalar Better Todo Tree by Fanatic Pythoner

        //TODO: indican tareas pendientes por implementar o finalizar

        //FIXME: señalan errores o problemas que deben ser corregidos


        //Impresión por consola
        System.out.println("Hola Mundo!");
        //atajo de teclado sout + tab
        
        //Atajo de teclado para indentar el código automáticamente
        // alt + shift + f

        //Para ejecutar el código utilizamos Run o su atajo de teclado.     

        /*        
        camelCase
        PascalCase
        snake_case
        kebab-case        
        */



    }
}
